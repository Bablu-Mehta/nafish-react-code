import { useState } from "react";
import "./App.css";
import "./style.css";
import axios from "axios";
function App() {
  const [data, setData] = useState({
    celcius: 10,
    name: "London",
    humidity: 10,
    speed: 2,
    image: "image1.jpg",
  });
  // useEffect(() => {
  //   const apiUrl =  "https://api.openweathermap.org/data/2.5/weather?q=London&appid=f29df762e5cd9be6d6c5f9f515325d40&&units=metric"
  //   axios.get(apiUrl)

  //     .then((res) => console.log(res))
  //     .catch((err) => console.log(err));
  // }, []);
  const [name, setName] = useState("");
  const handleClick = () => {
    if (name !== " ") {
      const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${name}&appid=f29df762e5cd9be6d6c5f9f515325d40&units=metric`;
      axios
        .get(apiUrl)
        .then((response) => {
          let imagePath = "image1.jpg";
          if (response.data.weather[0].main === "Clouds") {
            imagePath = "image1.jpg";
          } else if (response.data.weather[0].main === "Clear") {
            imagePath = "imageClear.jpeg";
          } else if (response.data.weather[0].main === "Rain") {
            imagePath = "imageRain.jpeg";
          } else if (response.data.weather[0].main === "Mist") {
            imagePath = "imageMist.jpeg";
          } else {
            imagePath = "image1.jpg";
          }
          setData({
            ...data,
            celcius: response.data.main.temp,
            name: response.data.name,
            humidity: response.data.main.humidity,
            speed: response.data.wind.speed,
            image: imagePath,
          });
        })
        .catch((error) => {
          console.error("Error fetching weather data:", error);
        });
    }
  };
  console.log(data, "--------------->");
  return (
    <div className="container">
      <div className="weather">
        <input
          style={{}}
          type="text"
          placeholder="Enter City Name"
          onChange={(e) => setName(e.target.value)}
        />
        <button>
          <img
            style={{ width: "20px" }}
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8OPCB4ygLpX406DuVkxusr6wSNIhws_TUhA&s"
            onClick={handleClick}
            alt=""
          />
        </button>
        <div className="winfo">
          <img style={{ marginTop: "20px" }} src={data.image} alt="" />
          <h1>{Math.round(data.celcius)}°c</h1>
          <h2>{data.name}</h2>
          <div className="details">
            <div className="col">
              <img
                style={{ width: "100px" }}
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2FTFFAIvekcGDtTFC3s5O_BcmhgX5f9B2Jg&s"
                alt=""
              />
              <div>
                <h1>{Math.round(data.humidity)}%</h1>
                <h2>Humidity</h2>
              </div>
            </div>
            <div className="col">
              <img
                style={{ width: "100px" }}
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS5QFM2t7RIJrzFiVZvAQAZz0dT5vNJQuB-Qw&s"
                alt=""
              />
              <div>
                <h1>{Math.round(data.speed)} km/h</h1>
                <h2>wind</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
