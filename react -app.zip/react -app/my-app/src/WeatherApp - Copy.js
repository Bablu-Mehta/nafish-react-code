import React from 'react'

export default function WeatherApp() {
  return (
    <div>WeatherApp</div>
  )
}
